﻿#ifndef THREAD
#define THREAD

#include "thread.c"

void generator(int mode), Game(int mode, char demo[5]), insert(), win(), lose();
int check();

#endif
